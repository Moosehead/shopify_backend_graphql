from django.apps import AppConfig


class MarketplaceCartConfig(AppConfig):
    name = 'marketplace_cart'
